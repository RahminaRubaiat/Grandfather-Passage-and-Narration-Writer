// ignore_for_file: prefer_const_constructors

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'instruction_screen.dart';
import 'recording_screens/spontaneousSpeech_record_screen.dart';

class TestPickerScreen extends StatefulWidget {
  TestPickerScreen({Key? key}) : super(key: key);

  @override
  State<TestPickerScreen> createState() => TestPickerScreenState();
}


class TestPickerScreenState extends State<TestPickerScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue,
      body: SingleChildScrollView(
        child: Container(
          decoration: const BoxDecoration(
              image: DecorationImage(
                  fit: BoxFit.cover,
                  image: AssetImage("assets/HD-wallpaper-black-gradient-black-gradient-background.jpg"))),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 50),
              Row(
                children: const [
                  Expanded(
                    child: Center(
                      child: Text(
                        'Available Tests\n',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 45,
                            color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                children: const [
                  Expanded(
                      child: Center(
                    child: Text(
                      'P^T^K^ Tests',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 30,
                          color: Colors.white),
                    ),
                  )),
                ],
              ),
              SizedBox(height:20),
              /*
              P Button
              */
              Row(
                children: [
                  Expanded(
                    child: Center(
                      child: SizedBox(
                        width: 187,
                        height: 45,
                        child: ElevatedButton(
                          child: const Text('P^'),
                          style: ElevatedButton.styleFrom(
                            side: const BorderSide(
                              width: 2.0,
                              color: Colors.white,
                            ),
                            foregroundColor: Colors.white,
                            backgroundColor: Color(0xffC5253B),
                            textStyle: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          onPressed: () {
                            setState(
                              () {
                                Navigator.of(context).pushReplacement(
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        //RecordAndPlayScreen(value: -1),
                                        InfoScreen(value: -1,testNum: 0,buttonValue: 0),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height:15),
              /*
              T Button
              */
              Row(
                children: [
                  Expanded(
                    child: Center(
                      child: SizedBox(
                        width: 187,
                        height: 45,
                        child: ElevatedButton(
                          child: const Text('T^'),
                          style: ElevatedButton.styleFrom(
                            side: const BorderSide(
                              width: 2.0,
                              color: Colors.white,
                            ),
                            foregroundColor: Colors.white,
                            backgroundColor: Color(0xffC5253B),
                            textStyle: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          onPressed: () {
                            setState(
                              () {
                                Navigator.of(context).pushReplacement(
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        //RecordAndPlayScreen(value: -1),
                                       InfoScreen(value: -1,testNum: 1,buttonValue: 0),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height:15),
              /*
              K Button
              */
              Row(
                children: [
                  Expanded(
                    child: Center(
                      child: SizedBox(
                        width: 187,
                        height: 45,
                        child: ElevatedButton(
                          child: const Text('K^'),
                          style: ElevatedButton.styleFrom(
                            side: const BorderSide(
                              width: 2.0,
                              color: Colors.white,
                            ),
                            foregroundColor: Colors.white,
                            backgroundColor: Color(0xffC5253B),
                            textStyle: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          onPressed: () {
                            setState(
                              () {
                                Navigator.of(context).pushReplacement(
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        //RecordAndPlayScreen(value: -1),
                                        InfoScreen(value: -1,testNum: 2,buttonValue: 0),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height:15),
              /*
              PTK Button
              */
              Row(
                children: [
                  Expanded(
                    child: Center(
                      child: SizedBox(
                        width: 187,
                        height: 45,
                        child: ElevatedButton(
                          child: const Text('P^T^K^'),
                          style: ElevatedButton.styleFrom(
                            side: const BorderSide(
                              width: 2.0,
                              color: Colors.white,
                            ),
                            foregroundColor: Colors.white,
                            backgroundColor: Color(0xffC5253B),
                            textStyle: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          onPressed: () {
                            setState(
                              () {
                                Navigator.of(context).pushReplacement(
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        //RecordAndPlayScreen(value: -1),
                                        InfoScreen(value: 10,testNum: 3,buttonValue: 0),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height:30),
              Row(
                children: const [
                  Expanded(
                      child: Center(
                    child: Text(
                      '\nSustained Vowel Tests',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 30,
                          color: Colors.white),
                    ),
                  )),
                ],
              ),
              SizedBox(height:20),
              /*
              Vowel /a/ button
              */
              Row(
                children: [
                  Expanded(
                    child: Center(
                      child: SizedBox(
                        width: 187,
                        height: 45,
                        child: ElevatedButton(
                          child: const Text('Vowel /a/'),
                          style: ElevatedButton.styleFrom(
                            side: const BorderSide(
                              width: 2.0,
                              color: Colors.white,
                            ),
                            foregroundColor: Colors.white,
                            backgroundColor: Color(0xffC5253B),
                            textStyle: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          onPressed: () {
                            setState(
                              () {
                                Navigator.of(context).pushReplacement(
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        //RecordAndPlayScreen(value: -1),
                                        InfoScreen(value: -1,testNum: 4,buttonValue: 0),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height:15),
              /*
              Vowel /e/ Button
              */
              Row(
                children: [
                  Expanded(
                    child: Center(
                      child: SizedBox(
                        width: 187,
                        height: 45,
                        child: ElevatedButton(
                          child: const Text('Vowel /e/'),
                          style: ElevatedButton.styleFrom(
                            side: const BorderSide(
                              width: 2.0,
                              color: Colors.white,
                            ),
                            foregroundColor: Colors.white,
                            backgroundColor: Color(0xffC5253B),
                            textStyle: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          onPressed: () {
                            setState(
                              () {
                                Navigator.of(context).pushReplacement(
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        //RecordAndPlayScreen(value: -1),
                                        InfoScreen(value: -1,testNum: 5,buttonValue: 0),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height:15),
              /*
              Vowel /o/ Button
              */
              Row(
                children: [
                  Expanded(
                    child: Center(
                      child: SizedBox(
                        width: 187,
                        height: 45,
                        child: ElevatedButton(
                          child: const Text('Vowel /o/'),
                          style: ElevatedButton.styleFrom(
                            side: const BorderSide(
                              width: 2.0,
                              color: Colors.white,
                            ),
                            foregroundColor: Colors.white,
                            backgroundColor: Color(0xffC5253B),
                            textStyle: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          onPressed: () {
                            setState(
                              () {
                                Navigator.of(context).pushReplacement(
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        //RecordAndPlayScreen(value: -1),
                                        InfoScreen(value: -1,testNum: 6,buttonValue: 0),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 60,
              ),
              Row(
                children: const [
                  Expanded(
                      child: Center(
                    child: Text(
                      'Passage Reading',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 30,
                          color: Colors.white),
                    ),
                  )),
                ],
              ),
              SizedBox(height:20),
              Row(
                children: [
                  Expanded(
                    child: Center(
                      child: SizedBox(
                        width: 187,
                        height: 45,
                        child: ElevatedButton(
                          child: const Text('Grandfather'),
                          style: ElevatedButton.styleFrom(
                            side: const BorderSide(
                              width: 2.0,
                              color: Colors.white,
                            ),
                            foregroundColor: Colors.white,
                            backgroundColor: Color(0xffC5253B),
                            textStyle: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          onPressed: () {
                            setState(
                                  () {
                                Navigator.of(context).pushReplacement(
                                  MaterialPageRoute(
                                    builder: (context) =>
                                    InfoScreen(value: -1,testNum: 7,buttonValue: 0),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height:15),
              Row(
                children: [
                  Expanded(
                    child: Center(
                      child: SizedBox(
                        width: 187,
                        height: 45,
                        child: ElevatedButton(
                          child: const Text('Rainbow'),
                          style: ElevatedButton.styleFrom(
                            side: const BorderSide(
                              width: 2.0,
                              color: Colors.white,
                            ),
                            foregroundColor: Colors.white,
                            backgroundColor: Color(0xffC5253B),
                            textStyle: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                         onPressed: () {
                            setState(
                                  () {
                                Navigator.of(context).pushReplacement(
                                  MaterialPageRoute(
                                    builder: (context) =>
                                    InfoScreen(value: -1,testNum: 8,buttonValue: 0),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height:15),
              Row(
                children: [
                  Expanded(
                    child: Center(
                      child: SizedBox(
                        width: 187,
                        height: 45,
                        child: ElevatedButton(
                          child: const Text('Please Call Stella'),
                          style: ElevatedButton.styleFrom(
                            side: const BorderSide(
                              width: 2.0,
                              color: Colors.white,
                            ),
                            foregroundColor: Colors.white,
                            backgroundColor: Color(0xffC5253B),
                            textStyle: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          onPressed: () {
                            setState(
                                  () {
                                Navigator.of(context).pushReplacement(
                                  MaterialPageRoute(
                                    builder: (context) =>
                                    InfoScreen(value: -1,testNum: 9,buttonValue: 0),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 40),
              Row(
                children: const [
                  Expanded(
                      child: Center(
                    child: Text(
                      'Spontaneous Speech',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 30,
                          color: Colors.white),
                    ),
                  )),
                ],
              ),
              SizedBox(height:20),
              Row(
                children: [
                  Expanded(
                    child: Center(
                      child: SizedBox(
                        width: 187,
                        height: 45,
                        child: ElevatedButton(
                          child: Text('Picnic Scene'),
                          style: ElevatedButton.styleFrom(
                            side: const BorderSide(
                              width: 2.0,
                              color: Colors.white,
                            ),
                            foregroundColor: Colors.white,
                            backgroundColor: Color(0xffC5253B),
                            textStyle: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          onPressed: () {
                            setState(
                                  () {
                                Navigator.of(context).pushReplacement(
                                  MaterialPageRoute(
                                    builder: (context) =>
                                    InfoScreen(value: -1,testNum: 10, buttonValue: 0,),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height:15),
              Row(
                children: [
                  Expanded(
                    child: Center(
                      child: SizedBox(
                        width: 187,
                        height: 45,
                        child: ElevatedButton(
                          child: const Text('Cookie Theft'),
                          style: ElevatedButton.styleFrom(
                            side: const BorderSide(
                              width: 2.0,
                              color: Colors.white,
                            ),
                            foregroundColor: Colors.white,
                            backgroundColor: Color(0xffC5253B),
                            textStyle: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                         onPressed: () {
                            setState(
                                  () {
                                Navigator.of(context).pushReplacement(
                                  MaterialPageRoute(
                                    builder: (context) =>
                                    InfoScreen(value: -1,testNum: 11, buttonValue: 0,),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              /*SizedBox(height: 40),
              Row(
                children: const [
                  Expanded(
                      child: Center(
                    child: Text(
                      'Sentence Reading',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 30,
                          color: Colors.white),
                    ),
                  )),
                ],
              ),
              SizedBox(height:20),
              Row(
                children: [
                  Expanded(
                    child: Center(
                      child: SizedBox(
                        width: 187,
                        height: 45,
                        child: ElevatedButton(
                          child: const Text('Wild Animals'),
                          style: ElevatedButton.styleFrom(
                            side: const BorderSide(
                              width: 2.0,
                              color: Colors.white,
                            ),
                            foregroundColor: Colors.white,
                            backgroundColor: Color(0xffC5253B),
                            textStyle: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          onPressed: () {
                            setState(
                                  () {
                                Navigator.of(context).pushReplacement(
                                  MaterialPageRoute(
                                    builder: (context) =>
                                    InfoScreen(value: -1,testNum: 12,buttonValue: 0),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 15),
              Row(
                children: [
                  Expanded(
                    child: Center(
                      child: SizedBox(
                        width: 187,
                        height: 45,
                        child: ElevatedButton(
                          child: const Text('Quick Brown Fox'),
                          style: ElevatedButton.styleFrom(
                            side: const BorderSide(
                              width: 2.0,
                              color: Colors.white,
                            ),
                            foregroundColor: Colors.white,
                            backgroundColor: Color(0xffC5253B),
                            textStyle: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          onPressed: () {
                            setState(
                                  () {
                                Navigator.of(context).pushReplacement(
                                  MaterialPageRoute(
                                    builder: (context) =>
                                    InfoScreen(value: -1,testNum: 13,buttonValue: 0),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 40),
              Row(
                children: const [
                  Expanded(
                      child: Center(
                    child: Text(
                      'Exective Function',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 30,
                          color: Colors.white),
                    ),
                  )),
                ],
              ),
              SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: Center(
                      child: SizedBox(
                        width: 187,
                        height: 45,
                        child: ElevatedButton(
                          child: const Text('Dec - Jan'),
                          style: ElevatedButton.styleFrom(
                            side: const BorderSide(
                              width: 2.0,
                              color: Colors.white,
                            ),
                            foregroundColor: Colors.white,
                            backgroundColor: Color(0xffC5253B),
                            textStyle: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          onPressed: () {
                            setState(
                                  () {
                                Navigator.of(context).pushReplacement(
                                  MaterialPageRoute(
                                    builder: (context) =>
                                    InfoScreen(value: -1,testNum: 14,buttonValue: 0),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),*/
              SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}
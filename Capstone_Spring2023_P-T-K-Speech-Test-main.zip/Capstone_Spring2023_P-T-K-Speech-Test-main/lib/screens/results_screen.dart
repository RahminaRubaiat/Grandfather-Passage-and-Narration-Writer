// ignore_for_file: prefer_const_constructors

import 'dart:ffi';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:record_with_play/screens/recording_screens/record_and_play_audio.dart';

/// Work in progress... Requires data analysis on audio recordings
/// to display all the different results in this page

class ShowResultsScreen extends StatefulWidget {
  final double testNum;
  ShowResultsScreen({Key? key, required this.testNum}) : super(key: key);
  
  @override
  State<ShowResultsScreen> createState() => ShowResultsState();
}

class ShowResultsState extends State<ShowResultsScreen> {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.grey[900],
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SizedBox(height: 45),
          Center(
            child: Text("P^T^K^ Results",
                style: TextStyle(
                  fontSize: 45,
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                )
            ),
          ),
          SizedBox(height: 20),
          Text("Test Report",
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.blue,
            ),
          ),
          SizedBox(height: 40),
          //Text("Test time: $seconds"),
          Divider(
            color: Colors.white,
            indent: 20.0,
            endIndent: 20.0,
            thickness: 2.0,
          ),
          SizedBox(height: 20),
          Text("DDK RATE:",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.blue,
            ),
          ),
          SizedBox(height: 50),
          Divider(
            color: Colors.white,
            indent: 20.0,
            endIndent: 20.0,
            thickness: 2.0,
          ),
          Text("RECORDING INFORMATION",
            style: TextStyle(
              fontSize: 20,
              color: Colors.red
            ),
          ),
          Divider(
            color: Colors.white,
            indent: 20.0,
            endIndent: 20.0,
            thickness: 2.0,
          ),
          Text("FURTHER GRAPHS AND INFORMATION",
            style: TextStyle(
                fontSize: 20,
                color: Colors.red
            ),
          ),
          Divider(
            color: Colors.white,
            indent: 20.0,
            endIndent: 20.0,
            thickness: 2.0,
          ),
          Text("EXPLANATION",
            style: TextStyle(
                fontSize: 20,
                color: Colors.red
            ),
          ),
          Divider(
            color: Colors.white,
            indent: 20.0,
            endIndent: 20.0,
            thickness: 2.0,
          ),
          SizedBox(height: 50),
          ElevatedButton(
            style: ButtonStyle(
              backgroundColor: MaterialStatePropertyAll(Colors.red),
            ),
              onPressed: () {
                Navigator.of(context).pushReplacement(MaterialPageRoute(
                  builder: (context) =>
                      RecordAndPlayScreen(value: 10,testNum: widget.testNum),
                      //Ensure it returns to correct recording screen
                ));
              },
              child: Text("Return home", style: TextStyle(fontSize: 16)))
        ],
      ),
    );
  }
  
}
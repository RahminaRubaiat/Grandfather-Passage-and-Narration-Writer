// ignore_for_file: prefer_const_constructors

import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:provider/provider.dart';
import 'package:record_with_play/providers/play_audio_provider.dart';
import 'package:record_with_play/screens/test_picker.dart';
import 'package:record_with_play/providers/record_audio_provider.dart';
import 'package:record_with_play/screens/instruction_screen.dart';
import 'package:record_with_play/screens/results_screen.dart';
import 'package:record_with_play/screens/time_picker.dart';
import 'package:record_with_play/services/file_upload.dart';
import 'package:simple_ripple_animation/simple_ripple_animation.dart';
import 'package:noise_meter/noise_meter.dart';
import 'package:record_with_play/services/file_upload.dart';

class RecordAndPlayScreen extends StatefulWidget {
  final double value;
  final double testNum;

  const RecordAndPlayScreen({Key? key, required this.value, required this.testNum}) : super(key: key);

  @override
  State<RecordAndPlayScreen> createState() => _RecordAndPlayScreenState();
}

class _RecordAndPlayScreenState extends State<RecordAndPlayScreen> {
  customizeStatusAndNavigationBar() {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        systemNavigationBarColor: Colors.white,
        statusBarColor: Colors.transparent,
        systemNavigationBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light));
  }
  bool sendRequest = true;

  @override
  void initState() {
    customizeStatusAndNavigationBar();
    super.initState();
    _noiseMeter = NoiseMeter(onError);
  }

  /// *********************** Decibel Meter Function ************************* ///
  bool _isRecording = false;
  StreamSubscription<NoiseReading>? _noiseSubscription;
  late NoiseMeter _noiseMeter;
  double? maxDB = 0;
  double? meanDB = 0;
  late int previousMillis;

  Widget decibelsIcons() {
    //print('Decibel:$maxDB');
    //While not recording
    if (!_isRecording) {
      return const SizedBox(
          width: 80,
          height: 100,
          child: Icon(CupertinoIcons.waveform, size: 80, color: Colors.white));
    } else {
      //Perfect speaking decibels range
      if (maxDB != null && maxDB! >= 56 && maxDB! <= 70) {
        return const SizedBox(
            width: 80,
            height: 100,
            child: Icon(CupertinoIcons.speaker_1_fill,
                size: 80, color: Colors.green));

        //Acceptable speaking decibels range
      } else if (maxDB != null && maxDB! > 70 && maxDB! <= 89) {
        return const SizedBox(
            width: 80,
            height: 100,
            child: Icon(CupertinoIcons.speaker_2_fill,
                size: 80, color: Colors.green));

        //Very loud speaking decibels range
      } else if (maxDB != null && maxDB! >= 90) {
        return const SizedBox(
            width: 80,
            height: 100,
            child: Icon(CupertinoIcons.volume_up, size: 96, color: Colors.red));
        //Under 40 db
      } else {
        return const SizedBox(
            width: 80,
            height: 100,
            child:
              Icon(CupertinoIcons.volume_off, size: 80, color: Colors.red));
      }
    }
  }
/*
  @override
  void initState() {
    super.initState();
    _noiseMeter = NoiseMeter(onError);
  }*/

  void onData(NoiseReading noiseReading) {
    setState(() {
      if (!_isRecording) _isRecording = true;
    });
    maxDB = noiseReading.maxDecibel;
    meanDB = noiseReading.meanDecibel;
  }

  void onError(Object e) {
    debugPrint(e.toString());
    _isRecording = false;
  }

  void start() async {
    print("Start called.");
    previousMillis = DateTime.now().millisecondsSinceEpoch;
    try {
      _noiseSubscription = _noiseMeter.noiseStream.listen(onData);
    } catch (e) {
      print(e);
    }
  }

  void stop() async {
    print("Stop called.");
    try {
      _noiseSubscription!.cancel();
      _noiseSubscription = null;

      setState(() => _isRecording = false);
    } catch (e) {
      debugPrint('stopRecorder error: $e');
    }
    previousMillis = 0;
  }

  /// *********************** Timer Widget Variables and Methods ************************* ///
  int time() {
    if (widget.value > 0) {
      return widget.value.toInt();
    } else {
      return widget.value.toInt() + 1;
    }
  }

  late int maxSeconds = time();
  late int seconds = maxSeconds;

  Timer? timer;

  void resetTimer() => setState(() => seconds = maxSeconds);

  void startTimer({bool reset = true}) {
    if (reset) {
      resetTimer();
    }

    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (seconds > 0 && widget.value > 0) {
        setState(() => {seconds--});
      } else if (widget.value == -1) {
        setState(() {
          seconds++;
        });
      } else {
        stopTimer(reset: false);
      }
    });
  }

  void stopTimer({bool reset = true}) {
    if (reset) {
      resetTimer();
    }
    setState(() => timer?.cancel());
  }


  @override
  Widget build(BuildContext context) {
    final recordProvider = Provider.of<RecordAudioProvider>(context);
    final playProvider = Provider.of<PlayAudioProvider>(context);

    return Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        decoration: const BoxDecoration(
            image: DecorationImage(
                fit: BoxFit.cover,
                image: AssetImage("assets/HD-wallpaper-black-gradient-black-gradient-background.jpg"))),
        child: Column(
          children: [
            SizedBox(height: 50),
            Center(
              child: Text(widget.testNum < 5 ? "P^T^K^" : "Sustained Vowel",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 50,
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  )),
            ),
            SizedBox(height: 70),
            Row(
              children: [
                SizedBox(width: 35),
                /*
                Info Page
                 */
                Container(
                  child: InkWell(
                      child: Icon(Icons.info_outline,
                          color: Colors.white, size: 80),
                      onTap: () {
                        Navigator.of(context).pushReplacement(
                          MaterialPageRoute(
                            builder: (context) =>
                                InfoScreen(value: widget.value, buttonValue: 1,testNum: widget.testNum),
                          ),
                        );
                      }),
                ),
                SizedBox(width: 50),
                /*
                Noise Meter
                */
                Container(
                  /*child: const Icon(
                    Icons.volume_up_sharp,
                    color: Colors.white,
                    size: 80,
                  ),*/
                  child: decibelsIcons(),
                ),
                SizedBox(width: 47),
                /*
                Clock
                */
                InkWell(
                  child: Icon(Icons.access_time_rounded,
                      color: Colors.white, size: 80),
                  onTap: () {
                    Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (context) => TimePickerScreen(
                          value: widget.value, testNum: widget.testNum), //send double value back to time picker page
                    ));
                  },
                ),
              ],
            ),
            Row(
              children: [
                SizedBox(width: 57),
                Text(
                  "Info",
                  //textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(width: 65),
                Text(
                  "Voice Level",
                  //textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(width: 55),
                if (widget.value > 0)
                  _secondsText()
                else
                  Padding(
                    padding: const EdgeInsets.only(left: 5.0),
                    child: const Icon(
                      //Icons.arrow_upward_outlined,
                        CupertinoIcons.infinite,
                        color: Colors.white),
                  )
              ],
            ),
            /*
            Row(
              children: [
              FloatingActionButton.extended(
                    label: Text(
                        _isRecording ? 'Stop recording' : 'Start recording'),
                    onPressed: _isRecording ? stop : start,
                    icon: !_isRecording ? const Icon(Icons.circle) : null,
                    backgroundColor: _isRecording ? Colors.red : Colors.green,
                  ),
            ],),*/
            const SizedBox(height: 40),
            if (!recordProvider.recordedFilePath.isEmpty) _playAudioHeading(),
            const SizedBox(height: 20),
            if (recordProvider.recordedFilePath.isEmpty)
              buildTimer()
            else
              _audioPlayingSection(),
            if (recordProvider.recordedFilePath.isNotEmpty &&
                !playProvider.isSongPlaying)
              const SizedBox(height: 40),
            if (recordProvider.recordedFilePath.isNotEmpty &&
                !playProvider.isSongPlaying)
              (showResultsButton())
          ],
        ),
      ),
    );
  }

  _recordHeading() {
    return const Center(
      child: Text(
        'Record Audio',
        style: TextStyle(
            fontSize: 26, fontWeight: FontWeight.w700, color: Colors.white),
      ),
    );
  }

  _playAudioHeading() {
    return const Center(
      child: Text(
        'Play Audio',
        style: TextStyle(
            fontSize: 22, fontWeight: FontWeight.w700, color: Colors.white),
      ),
    );
  }

  _secondsText() {
    return Text(
      "$maxSeconds s",
      //textAlign: TextAlign.center,
      style: TextStyle(
        fontSize: 20,
        color: Colors.white,
        fontWeight: FontWeight.w500,
      ),
    );
  }

  _recordingSection() {
    final isRunning = timer == null ? false : timer!.isActive;
    final recordProvider = Provider.of<RecordAudioProvider>(context);
    final recordProviderWithoutListener =
      Provider.of<RecordAudioProvider>(context, listen: false);

    if (recordProvider.isRecording) {
      if (isRunning) {
      } else if (seconds == 0 && widget.value > 0) {
        stopRecording();
        stopTimer();
        stop();
      } else {
        print("Start timer");
        startTimer();
      }

      return Column(
        children: [
          buildTime(),
          SizedBox(height: 20),
          InkWell(
            onTap: () async => {
              await recordProviderWithoutListener.stopRecording(),
              stop(),
            },
            child: RippleAnimation(
              repeat: true,
              color: Color(0xffC5253B),
              minRadius: 40,
              ripplesCount: 6,
              child: _commonIconSection(),
            ),
          ),
          SizedBox(height: 30),
          cancelButton(),
        ],
      );
    }

    return Column(
      children: [
        _recordHeading(),
        SizedBox(height: 20),
        InkWell(
          onTap: () async => {
            await recordProviderWithoutListener.recordVoice(),
            //_isRecording ? stop : start,
            start(),
            print("Start recording")
            //_isRecording = true
          },
          child: _commonIconSection(),
        ),
        SizedBox(height: 26),
      ],
    );
  }

  _commonIconSection() {
    return Container(
      width: 100,
      height: 100,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Color(0xffC5253B),
        borderRadius: BorderRadius.circular(100),
      ),
      child: const Icon(Icons.keyboard_voice_rounded,
          color: Colors.white, size: 50),
    );
  }

  _audioPlayingSection() {
    final recordProvider = Provider.of<RecordAudioProvider>(context);

    // Need fixing, gets constantly called when listening to playback
    // uploadFile(recordProvider.recordedFilePath);

    return Container(
      width: MediaQuery.of(context).size.width - 110,
      height: 50,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: Colors.white,
      ),
      child: Row(
        children: [
          _audioControllingSection(recordProvider.recordedFilePath),
          _audioProgressSection(),
        ],
      ),
    );
  }

  _audioControllingSection(String songPath) {
    final playProvider = Provider.of<PlayAudioProvider>(context);
    final playProviderWithoutListen =
        Provider.of<PlayAudioProvider>(context, listen: false);

    return IconButton(
      onPressed: () async {
        if (songPath.isEmpty) {}

        await playProviderWithoutListen.playAudio(File(songPath));
      },
      icon: Icon(
          playProvider.isSongPlaying ? Icons.pause : Icons.play_arrow_rounded),
      color: const Color(0xff4BB543),
      iconSize: 35,
    );
  }

  _audioProgressSection() {
    final playProvider = Provider.of<PlayAudioProvider>(context);

    return Expanded(
        child: Container(
          width: double.maxFinite,
          margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          child: LinearPercentIndicator(
            percent: playProvider.currLoadingStatus,
            backgroundColor: Colors.black26,
            progressColor: const Color(0xff4BB543),
          ),
        ));
  }

  _resetButton() {
    final isRunning = timer == null ? false : timer!.isActive;
    final recordProvider =
    Provider.of<RecordAudioProvider>(context, listen: false);

    if (isRunning) {
      print("Reset timer");
      stopTimer();
    }

    return InkWell(
      onTap: () => recordProvider.clearOldData(),
      child: Center(
        child: Container(
          width: 80,
          alignment: Alignment.center,
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          decoration: BoxDecoration(
            color: Color(0xffC5253B),
            borderRadius: BorderRadius.circular(10),
          ),
          child: const Text(
            'Reset',
            style: TextStyle(fontSize: 19, color: Colors.white),
          ),
        ),
      ),
    );
  }

  stopRecording() async {
    final recordProviderWithoutListener =
    Provider.of<RecordAudioProvider>(context, listen: false);
    final playProviderWithoutListen =
    Provider.of<PlayAudioProvider>(context, listen: false);

    await recordProviderWithoutListener.stopRecording();
  }

  showResultsButton() {
   return Column(
     children: [
       Text(
         "PaTaKa Test Accuracy: ",
         style: TextStyle(
             fontSize: 25, fontWeight: FontWeight.bold, color: Colors.white),
       ),
       SizedBox(height: 40),
       TextButton(
         style: ButtonStyle(
           backgroundColor: MaterialStateProperty.all(Colors.white),
         ),
         child: Text(
           "Show Results",
           style: TextStyle(fontSize: 20, color: Colors.black),
         ),
         onPressed: () {
           Navigator.of(context).pushReplacement(
               MaterialPageRoute(builder: (context) => ShowResultsScreen(testNum: widget.testNum)));
         },
       ),
       SizedBox(height: 30),
       //_resetButton(),
       pickDifferentTestButton(),
     ],
   );
 }


 pickDifferentTestButton() {
   return Column(
     children: [
       TextButton(
         style: ButtonStyle(
           backgroundColor: MaterialStateProperty.all(Colors.white),
         ),
         child: Text(
           "Homepage",
           style: TextStyle(fontSize: 20, color: Colors.black),
         ),
         onPressed: () {
           Navigator.of(context).pushReplacement(
               MaterialPageRoute(builder: (context) => TestPickerScreen()));
           final isRunning = timer == null ? false : timer!.isActive;
           final recordProvider = Provider.of<RecordAudioProvider>(context, listen: false);
           recordProvider.clearOldData();


   if (isRunning) {
     print("Reset timer");
     stopTimer();
   }
         },
       ),
       SizedBox(height: 30),
       _resetButton(),
     ],
   );
 }





  /// *********************** Widgets for all the Timer buttons and functionality ****************************
  Widget buildTimer() {
    return SizedBox(
      width: 350,
      height: 350,
      child: Stack(
        fit: StackFit.expand,
        children: [
          CircularProgressIndicator(
            value: maxSeconds > 0 ? 1 - seconds / maxSeconds : 1 / 1,
            valueColor: AlwaysStoppedAnimation(Colors.grey[800]),
            strokeWidth: 12,
            backgroundColor: Colors.white,
          ),
          Center(
              child: Padding(
                padding: const EdgeInsets.only(bottom: 30.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _recordingSection(),
                  ],
                ),
              )),
        ],
      ),
    );
  }

  Widget buildTime() {
    return Text(
      "$seconds",
      style: TextStyle(
        fontSize: 70,
        color: Colors.white,
        fontWeight: FontWeight.bold,
      ),
    );
    //}
  }

  cancelButton() {
    final isRunning = timer == null ? false : timer!.isActive;
    final recordProvider =
    Provider.of<RecordAudioProvider>(context, listen: false);
    final recordProviderWithoutListener =
    Provider.of<RecordAudioProvider>(context, listen: false);

    return Container(
      width: 90,
      decoration: BoxDecoration(
        color: Color(0xffC5253B),
        borderRadius: BorderRadius.circular(10),
      ),
      child: TextButton(
        onPressed: () async {
          await recordProviderWithoutListener.stopRecording();
          recordProvider.clearOldData();
          if (isRunning) {
            print("Cancel timer");
            stopTimer();
            stop();
          }
        },
        child: Text(
          "Cancel",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
          ),
        ),
      ),
    );
  }
}

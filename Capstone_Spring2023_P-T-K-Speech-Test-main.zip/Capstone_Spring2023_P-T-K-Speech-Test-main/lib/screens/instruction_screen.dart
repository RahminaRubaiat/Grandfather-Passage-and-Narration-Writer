// ignore_for_file: prefer_const_constructors

import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:record_with_play/screens/recording_screens/grandfather_record_screen.dart';
import 'package:record_with_play/screens/recording_screens/record_and_play_audio.dart';
import 'recording_screens/spontaneousSpeech_record_screen.dart';


class InfoScreen extends StatefulWidget {
  final double value;
  final double buttonValue;
  final double testNum;

  const InfoScreen({Key? key, required this.value, required this.buttonValue,required this.testNum})
      : super(key: key);

  @override
  State<InfoScreen> createState() => InfoScreenState();
  
}

setTestAudio(testNum){
  switch (testNum) {
    //PTK Tests
    case 0:
      return "assets/InstructionsPA.mp3";
    case 1:
      return "assets/InstructionsTA.mp3";  
    case 2:
      return "assets/InstructionsKA.mp3"; 
    case 3:
      return "assets/PaTaKaInstructionRecording.mp3"; 
    //Sustained Vowel Tests    
    case 4:
      return "assets/InstructionsAH.mp3";  
    case 5:
      return "assets/InstructionsAH.mp3";  
    case 6:
      return "assets/InstructionsAH.mp3";  
    //Passage Reading  
    case 7:
      return "assets/InstructionsAH.mp3";  
    case 8:   
      return "assets/PaTaKaInstructionRecording.mp3";  
    case 9:   
      return "assets/PaTaKaInstructionRecording.mp3";  
     //Spontaneous Speech
    case 10:   
      return "assets/PaTaKaInstructionRecording.mp3";  
    case 11:   
      return "assets/PaTaKaInstructionRecording.mp3";   
    //Sentence Reading
    case 12:
      return "assets/PaTaKaInstructionRecording.mp3";  
    case 13:
      return "assets/PaTaKaInstructionRecording.mp3";  
    //Executive Function
    case 14:
      return "assets/PaTaKaInstructionRecording.mp3";  
    default:
      return "assets/PaTaKaInstructionRecording.mp3";
  }
}

setTestText(testNum){
  switch (testNum) {
    //PTK Tests
    case 0:
      return "Take a breath of air and say \n "
                  "\"pa pa pa pa pa\"\n" 
                  "as fast, as long, \n "
                  "and as steadily as you can.";
    case 1:
      return "Take a breath of air and say \n "
                  "\"ta ta ta ta ta\"\n"
                   "as fast, as long, \n "
                  "and as steadily as you can.";   
    case 2:
      return "Take a breath of air and say \n "
                  "\"ka ka ka ka ka\"\n"
                  "as fast, as long, \n "
                  "and as steadily as you can."; 
    case 3:
      return "Take a breath of air and say \n "
                  "\"pataka pataka pataka pataka \n "
                  "pataka\" as fast, as long, \n "
                  "and as steadily as you can.";  
    //Sustained Vowel Tests              
    case 4:
      return "Take a breath of air and say \n "
                  "\"a a a a a aa a a a a a a\"\n" 
                  "as steadily as you can."; 
    case 5:
      return "Take a breath of air and say \n "
                  "\"e e e e e e e e e e e e\"\n" 
                  "as steadily as you can."; 
    case 6:
      return "Take a breath of air and say \n "
                  "\"o o o o o o o o o o o o\"\n" 
                  "as steadily as you can.";
    //Passage Reading  
    case 7:
      return "Read the passage aloud at a comfortable pace.";
            
    case 8:   
      return "Read the passage aloud at a comfortable pace.\n";
             //"Pay attention to your pronunciation and intonation.\n"
             //"If you make a mistake, don't worry about it. Just keep reading.\n";
    case 9:   
      return "Read the passage aloud at a comfortable pace.";
             //"Pay attention to your pronunciation and intonation.\n"
             //"If you make a mistake, don't worry about it. Just keep reading.\n"; 
    //Spontaneous Speech  
    case 10:   
      return "Provide a detailed description\n"
             "of what is happening in the \n"
             "picture"; 
    case 11:   
      return "Provide a detailed description\n"
             "of what is happening in the \n"
             "picture";  
    //Sentence Reading
    case 12:
      return "PLACEHOLDER"; 
    case 13:
      return "PLACEHOLDER";  
    //Executive Function  
    case 14:
      return "PLACEHOLDER";  
    default:
      return "Selection Invalid";
  }
}

class InfoScreenState extends State<InfoScreen> {
  final player = AudioPlayer();
  bool isPlaying = false; //keep track of audio status
  StreamSubscription<PlaybackEvent>?
  _playbackSubscription; //listens for audio changes

  @override
  void initState() {
    super.initState();
    print("In init state");

    _playbackSubscription = player.playbackEventStream.listen((event) {
      /*
      setState(() {//set state once a change in audio has been detected
        //isPlaying = player.playing;
      }); (I don't believe setting state here is necessary)*/
      if (event.processingState == ProcessingState.completed) {
        print("Changing button color.");
        //if audio is complete
        setState(() {
          isPlaying = false;
        });
      }
    });
  }

  @override
  void dispose() {
    _playbackSubscription?.cancel();
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
            image: DecorationImage(
                fit: BoxFit.cover,
                image: AssetImage("assets/HD-wallpaper-black-gradient-black-gradient-background.jpg"))),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              // ignore: prefer_const_literals_to_create_immutables
              children: [
                Text(
                  "Instructions",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
                SizedBox(width: 15),
                InkWell(
                    child:
                    isPlaying
                        ? Icon(CupertinoIcons.speaker_2_fill,
                        size: 40, color: Colors.yellow)
                        : Icon(CupertinoIcons.speaker_2_fill,
                        size: 40, color: Colors.white),
                    onTap: () async {
                        await player
                          .setAsset(setTestAudio(widget.testNum));
                      player.play();
                      setState(() {
                        print("State is being set: ");
                        //isPlaying = true;
                        isPlaying ? isPlaying = false : isPlaying = true;
                        if (!isPlaying) {
                          player.stop();
                        }
                      });
                      
                    }
                )
              ],
            ),
            SizedBox(height: 30),
            Center(
              child:
                     Text(setTestText(widget.testNum),
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ),
            SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStatePropertyAll(Color(0xffC5253B)),
                    foregroundColor: MaterialStatePropertyAll(Colors.white),
                  ),
                  onPressed: () {
                    player.stop();
                    //PTK Record Screen
                    if(widget.testNum <= 3){
                        Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (context) =>
                            RecordAndPlayScreen(value: widget.value,testNum: widget.testNum),
                        ));
                    } 
                    //Create a unified record screen for "Sustained Vowel Test"
                    else if(widget.testNum > 3 && widget.testNum <= 6){
                        Navigator.of(context).pushReplacement(MaterialPageRoute(
                        builder: (context) =>
                          RecordAndPlayScreen(value: widget.value, testNum: widget.testNum),
                        ));
                    }
                    //Passage Test Record Screen
                    else if(widget.testNum > 6 && widget.testNum <= 9){
                        Navigator.of(context).pushReplacement(MaterialPageRoute(
                        builder: (context) =>
                          GrandfatherRecordScreen(value: widget.value, testNum: widget.testNum),  
                        ));
                    } 
                    //Spontaneous Test Record Screen
                    else if(widget.testNum == 10 || widget.testNum == 11){
                        Navigator.of(context).pushReplacement(MaterialPageRoute(
                        builder: (context) =>
                          SpontaneousSpeechScreen(value: widget.value, testNum: widget.testNum),  
                        ));
                    } 
                    //Sentence Reading Test Record Screen
                    else if(widget.testNum == 12 ||  widget.testNum == 13){
                        Navigator.of(context).pushReplacement(MaterialPageRoute(
                        builder: (context) =>
                          SpontaneousSpeechScreen(value: widget.value, testNum: widget.testNum),
                        ));
                    }
                    //Executive Function Test Record Screen
                    else if(widget.testNum == 14){
                        Navigator.of(context).pushReplacement(MaterialPageRoute(
                        builder: (context) =>
                          SpontaneousSpeechScreen(value: widget.value, testNum: widget.testNum),
                        ));
                    }
                  },
                  
                  //},
                  child: widget.buttonValue ==
                      0 //entered page from test picker page
                      ? const Text(
                    "Begin Test",
                    style: TextStyle(
                      fontSize: 16,
                    ),
                  )
                      : const Text(
                    //entered page from the test page
                    "Return To Test",
                    style: TextStyle(
                      fontSize: 16,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
// ignore_for_file: prefer_const_constructors

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:record_with_play/screens/recording_screens/record_and_play_audio.dart';

class TimePickerScreen extends StatefulWidget {
  double value;
  final double testNum;

  TimePickerScreen({Key? key, required this.value, required this.testNum}) : super(key: key);

  @override
  State<TimePickerScreen> createState() => _TimePickerScreenState();
}

class _TimePickerScreenState extends State<TimePickerScreen> {
  bool timerButtonFirstPress = false;
  bool _timerButtonPressed = true;
  bool _manualButtonPressed = false;
  bool _manualButtonFirstPress = true;

  double getTime() {
    if (widget.value == -1) {
      return 10;
    } else {
      return widget.value;
    }
  }

  late double time = getTime();
  double manual = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.blue,
        body: Container(
          decoration: const BoxDecoration(
              image: DecorationImage(
                  fit: BoxFit.cover,
                  image: AssetImage("assets/HD-wallpaper-black-gradient-black-gradient-background.jpg"))),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                children: [
                  SizedBox(width: 40),

                  /*
                  Timer Button
                  */
                  Expanded(
                    child: ElevatedButton(
                      child: Text('Timed'),
                      style: _timerButtonPressed
                          ? ElevatedButton.styleFrom(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(5),
                                      bottomLeft: Radius.circular(5))),
                              backgroundColor: Colors.white,
                              foregroundColor: Color(0xffC5253B),
                              textStyle: const TextStyle(
                                  fontSize: 20, fontStyle: FontStyle.normal),
                            )
                          : ElevatedButton.styleFrom(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(5),
                                      bottomLeft: Radius.circular(5))),
                              backgroundColor: Color(0xffC5253B),
                              foregroundColor: Colors.white,
                              textStyle: const TextStyle(
                                  fontSize: 20, fontStyle: FontStyle.normal),
                            ),
                      onPressed: () => {
                        if (timerButtonFirstPress)
                          {
                            setState(() {
                              manual = 0;
                              timerButtonFirstPress = false;
                              _timerButtonPressed = !_timerButtonPressed;
                              _manualButtonPressed = !_manualButtonPressed;
                              _manualButtonFirstPress = true;
                            })
                          }
                      },
                    ),
                  ),
                  /*
                  Manual Button
                  */
                  Expanded(
                    child: ElevatedButton(
                      child: Text('Manual'),
                      style: _manualButtonPressed
                          ? ElevatedButton.styleFrom(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(5),
                                      bottomRight: Radius.circular(5))),
                              backgroundColor: Colors.white,
                              foregroundColor: Color(0xffC5253B),
                              textStyle: const TextStyle(
                                  fontSize: 20, fontStyle: FontStyle.normal),
                            )
                          : ElevatedButton.styleFrom(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(5),
                                      bottomRight: Radius.circular(5))),
                              backgroundColor: Color(0xffC5253B),
                              foregroundColor: Colors.white,
                              textStyle: const TextStyle(
                                  fontSize: 20, fontStyle: FontStyle.normal),
                            ),
                      onPressed: () => {
                        if (_manualButtonFirstPress)
                          {
                            setState(() {
                              manual = -1;
                              _manualButtonFirstPress = false;
                              timerButtonFirstPress = true;
                              _manualButtonPressed = !_manualButtonPressed;
                              _timerButtonPressed = !_timerButtonPressed;
                            })
                          }
                      },
                    ),
                  ),
                  SizedBox(width: 40),
                ],
              ),
              Row(
                children: [SizedBox(height: 50)],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("${time.round()} seconds",
                      style: TextStyle(
                          fontSize: 25,
                          fontWeight: FontWeight.w500,
                          color: _timerButtonPressed
                              ? Colors.white
                              : Colors.blueGrey.shade700)),
                ],
              ),
              Row(
                children: [
                  SizedBox(width: 70),
                  Text(
                    "-",
                    style: TextStyle(
                      fontSize: 60,
                      color: _timerButtonPressed
                          ? Colors.white
                          : Colors.blueGrey.shade700,
                      fontWeight: FontWeight.w200,
                    ),
                  ),
                  Expanded(
                    child: SliderTheme(
                      data: SliderThemeData(
                        /*
                        Slider UI data for when manual button is pressed.
                        */
                        disabledActiveTrackColor: Colors.blueGrey.shade700,
                        disabledInactiveTrackColor: Colors.blueGrey.shade700,
                        disabledThumbColor: Colors.blueGrey.shade600,
                        disabledInactiveTickMarkColor: Colors.transparent,
                        disabledActiveTickMarkColor: Colors.transparent,
                        /*
                        Slider UI data for when timed button is pressed.
                        */
                        activeTickMarkColor: Colors.transparent,
                        inactiveTickMarkColor: Colors.transparent,
                        thumbColor: Colors.white,
                        activeTrackColor: Colors.white,
                        inactiveTrackColor: Colors.blueGrey.shade700,
                      ),
                      child: Slider(
                          value: time,
                          min: 5,
                          max: 15, 
                          //divisions: 15,
                          onChanged: _timerButtonPressed
                              ? (value) => setState(() => time = value)
                              : null),
                    ),
                  ),
                  Icon(
                    Icons.add_outlined,
                    color: _timerButtonPressed
                        ? Colors.white
                        : Colors.blueGrey.shade700,
                  ),
                  SizedBox(width: 70),
                ],
              ),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStatePropertyAll(Color(0xffC5253B)),
                  ),
                  onPressed: () {
                    if (manual == 0) {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                        builder: (context) => RecordAndPlayScreen(value: time,testNum: widget.testNum),
                        //Ensure it returns to correct recording screen
                      ));
                    } else {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                        builder: (context) =>
                            RecordAndPlayScreen(value: manual,testNum: widget.testNum),
                            //Ensure it returns to correct recording screen
                      ));
                    }
                  },
                  child: const Text("Confirm", style: TextStyle(
                          fontSize: 23,
                          fontWeight: FontWeight.w500,)),
                )
              ])
            ],
          ),
        )
      );
  }
}

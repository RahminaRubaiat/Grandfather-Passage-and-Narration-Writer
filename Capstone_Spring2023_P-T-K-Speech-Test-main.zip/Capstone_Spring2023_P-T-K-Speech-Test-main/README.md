# Smartphone-Based-SpeechAssessment

A mobile application that allows for users to record their voice when performing various
speech assesment test to go through audio analytics software such as Whisper, Librosa and Pratt to
be reviewed and diagnosed by a Speech Pathologist.

## Getting Started

Required software to run this application are : 
- [Flutter](https://docs.flutter.dev/get-started/install) 
- [Visual Studio](https://code.visualstudio.com/) or [Android Studio](https://developer.android.com/studio)

Testing of the application has been done through an emulator avalable from the above IDE's
These are the Emulators that have been used to test the application:
- Pixel 4 XL - Tiramisu - API 33
- Pixel 5 - Tiramisu - API 33

NOTE - If you have a decent Computer, set the Grpahics for the emulator to Hardware GLES 2.0 for better performance. 
Make sure to run "flutter pub get" before running the application on the emulator to get all the required dependencies
used for the project. If you still can't run the application, run "flutter clean" and then "flutter pub get" and try again.

## References 
The following videos were implemented or used as reference to create this project 
- [Flutter Tutorial | Record Audio and Play Audio | Provider](https://www.youtube.com/watch?v=27AShekuMnQ)
- [Flutter Tutorial - Simple Countdown Timer | With Start, Pause, Cancel](https://www.youtube.com/watch?v=bjAsnIw3VCs&t=533s)
- [Noise meter](https://github.com/iqfareez/noise_meter_flutter)
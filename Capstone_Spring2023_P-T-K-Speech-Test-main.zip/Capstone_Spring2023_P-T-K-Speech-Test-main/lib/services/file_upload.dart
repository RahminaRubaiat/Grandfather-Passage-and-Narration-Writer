import 'dart:io';

import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

/// Upload does work when web serer and rest API is running, we get the
/// ok code but file is not appearing in the local file it's supposed to
/// be saved in. Must talk with Rafael and Enshi to figure out what isn't
/// working.

Future<void> uploadFile(String filename) async {

  // Localhost for emulator is 10.0.2.2
  var request = http.MultipartRequest("POST", Uri.parse("http://10.0.2.2:8080/koiosrestapi/files/upload_study_object?enrollmentId=29fd179a-fae2-46e3-a7ce-f9288b7f536d"));

  request.headers["secret"] = "koiosByAfzalFromNDmL@b";

  print("Dir- $filename");
  String path = "/storage/emulated/0/Android/data/com.example.record_with_play/files/recordings/";
  String audioName = filename.substring(path.length, filename.length);
  print(audioName);

  request.files.add(await http.MultipartFile.fromPath("file", filename));

  var response = await request.send();
  var responseData = await response.stream.toBytes();
  var results = String.fromCharCodes(responseData);

  print(results);
  print(response.reasonPhrase);


}


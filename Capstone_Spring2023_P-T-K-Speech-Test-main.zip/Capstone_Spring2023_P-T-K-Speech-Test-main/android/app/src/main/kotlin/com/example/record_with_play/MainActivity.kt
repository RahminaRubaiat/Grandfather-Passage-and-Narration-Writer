package com.example.record_with_play

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
